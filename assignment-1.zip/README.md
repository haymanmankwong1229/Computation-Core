# 聚餐分帳計算器

## 學生姓名
張三

## 使用說明
1. 確保已安裝 Node.js 和 npm。
2. 執行 `npm install` 以安裝依賴項。
3. 使用 `npm test` 進行單元測試。